import os
import requests

BASE_URL = "https://api-m.sandbox.paypal.com"  # Intentionally sandbox-only in this starter.
TIMEOUT_SECONDS = 20


class PayPalError(RuntimeError):
    pass


def _credentials() -> tuple[str, str]:
    client_id = os.getenv("PAYPAL_CLIENT_ID", "").strip()
    secret = os.getenv("PAYPAL_CLIENT_SECRET", "").strip()
    if not client_id or not secret or client_id.startswith("your_"):
        raise PayPalError("Set PAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET in backend/.env using Sandbox credentials.")
    return client_id, secret


def access_token() -> str:
    client_id, secret = _credentials()
    response = requests.post(
        f"{BASE_URL}/v1/oauth2/token",
        auth=(client_id, secret),
        headers={"Accept": "application/json", "Accept-Language": "en_US"},
        data={"grant_type": "client_credentials"},
        timeout=TIMEOUT_SECONDS,
    )
    if not response.ok:
        raise PayPalError(f"PayPal OAuth failed ({response.status_code}): {response.text[:400]}")
    token = response.json().get("access_token")
    if not token:
        raise PayPalError("PayPal did not return an access token.")
    return token


def get_capture(capture_id: str) -> dict:
    token = access_token()
    response = requests.get(
        f"{BASE_URL}/v2/payments/captures/{capture_id}",
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        timeout=TIMEOUT_SECONDS,
    )
    if not response.ok:
        raise PayPalError(f"PayPal capture lookup failed ({response.status_code}): {response.text[:400]}")
    return response.json()


def refund_capture(capture_id: str, request_id: str) -> dict:
    token = access_token()
    response = requests.post(
        f"{BASE_URL}/v2/payments/captures/{capture_id}/refund",
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "PayPal-Request-Id": request_id,
        },
        json={},
        timeout=TIMEOUT_SECONDS,
    )
    if response.status_code not in (200, 201, 202):
        raise PayPalError(f"PayPal refund failed ({response.status_code}): {response.text[:500]}")
    return response.json()
