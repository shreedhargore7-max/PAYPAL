import os
import secrets
import uuid
from datetime import datetime, timezone
from typing import Any

from dotenv import load_dotenv
from fastapi import Depends, FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

from . import db
from .agent import classify_complaint, evaluate_policy
from .paypal_client import PayPalError, get_capture, refund_capture

load_dotenv()
db.init_db()
app = FastAPI(title="ResolveOS API", version="0.1.0", description="AI-assisted payment support and human-approved PayPal sandbox refunds.")


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class CreateCaseRequest(BaseModel):
    order_id: str = Field(min_length=4, max_length=40)
    customer_message: str = Field(min_length=5, max_length=3000)


class LinkCaptureRequest(BaseModel):
    capture_id: str = Field(min_length=5, max_length=80)


def require_admin(x_admin_key: str | None = Header(default=None, alias="X-Admin-Key")) -> str:
    expected = os.getenv("ADMIN_API_KEY", "").strip()
    if not expected or expected.startswith("replace-with-"):
        raise HTTPException(status_code=503, detail="Set a strong ADMIN_API_KEY in backend/.env before using merchant-only endpoints.")
    if not x_admin_key or not secrets.compare_digest(x_admin_key, expected):
        raise HTTPException(status_code=401, detail="Valid X-Admin-Key header required for this prototype merchant action.")
    return "merchant_admin"


def public_case(case: dict[str, Any]) -> dict[str, Any]:
    return {k: v for k, v in case.items() if k not in {"paypal_request_id"}}


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "service": "ResolveOS", "mode": "paypal-sandbox-only"}


@app.get("/orders")
def orders() -> list[dict[str, Any]]:
    """Seeded order/shipping rows are synthetic demo evidence, not PayPal records."""
    return db.list_orders()


@app.post("/orders/{order_id}/link-capture")
def link_paypal_capture(order_id: str, body: LinkCaptureRequest, _actor: str = Depends(require_admin)) -> dict[str, Any]:
    order = db.get_order(order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Order not found.")
    try:
        capture = get_capture(body.capture_id)
    except PayPalError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    amount = (capture.get("amount") or {})
    if capture.get("status") != "COMPLETED":
        raise HTTPException(status_code=409, detail=f"Capture must have COMPLETED status; current status is {capture.get('status')}.")
    if str(amount.get("value")) != str(order["amount"]) or amount.get("currency_code") != order["currency"]:
        raise HTTPException(status_code=409, detail="Capture amount/currency does not match this demo order. Use a matching Sandbox capture.")

    db.link_capture(order_id, body.capture_id)
    db.log_audit("SYSTEM-LINK", _actor, "PAYPAL_CAPTURE_LINKED", {"order_id": order_id, "capture_id": body.capture_id, "status": capture.get("status")})
    return {"linked": True, "order_id": order_id, "capture_id": body.capture_id, "paypal_status": capture.get("status"), "amount": amount}


@app.post("/cases")
def create_support_case(body: CreateCaseRequest) -> dict[str, Any]:
    order = db.get_order(body.order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Unknown order_id. Try one of the seeded orders returned by GET /orders.")

    # When a capture is linked, fetch its current state from PayPal rather than trusting local state.
    paypal_note = None
    if order.get("paypal_capture_id"):
        try:
            capture = get_capture(order["paypal_capture_id"])
            order["payment_status"] = capture.get("status", order["payment_status"])
            amount = capture.get("amount") or {}
            if str(amount.get("value")) != str(order["amount"]) or amount.get("currency_code") != order["currency"]:
                raise HTTPException(status_code=409, detail="Linked PayPal capture no longer matches order amount/currency.")
        except PayPalError as exc:
            paypal_note = str(exc)

    classification = classify_complaint(body.customer_message, order)
    decision, reasons = evaluate_policy(classification, order)
    case_id = f"CASE-{uuid.uuid4().hex[:10].upper()}"
    status_by_decision = {
        "REFUND_CANDIDATE": "AWAITING_MERCHANT_APPROVAL",
        "AWAITING_CAPTURE_LINK": "AWAITING_CAPTURE_LINK",
        "NEEDS_MORE_INFORMATION": "NEEDS_MORE_INFORMATION",
        "NEEDS_HUMAN_REVIEW": "NEEDS_HUMAN_REVIEW",
        "NO_NEW_REFUND": "CLOSED_NO_ACTION",
    }
    case = {
        "case_id": case_id,
        "order_id": body.order_id,
        "customer_message": body.customer_message,
        "issue_type": classification["issue_type"],
        "summary": classification["summary"],
        "policy_decision": decision,
        "reasons": reasons,
        "status": status_by_decision.get(decision, "NEEDS_HUMAN_REVIEW"),
        "confidence": classification["confidence"],
        "paypal_request_id": None,
        "paypal_refund_id": None,
        "refund_status": None,
        "created_at": now_iso(),
        "updated_at": now_iso(),
    }
    db.create_case(case)
    db.log_audit(case_id, "AI_AGENT", "CASE_ANALYZED", {"issue_type": case["issue_type"], "policy_decision": decision, "reasons": reasons})
    result = {**public_case(case), "order": order}
    if paypal_note:
        result["paypal_lookup_warning"] = paypal_note
    return result


@app.get("/cases/{case_id}")
def get_support_case(case_id: str) -> dict[str, Any]:
    case = db.get_case(case_id)
    if not case:
        raise HTTPException(status_code=404, detail="Case not found.")
    case["order"] = db.get_order(case["order_id"])
    case["audit_log"] = db.get_audit(case_id)
    return public_case(case)


@app.post("/cases/{case_id}/approve-refund")
def approve_refund(case_id: str, actor: str = Depends(require_admin)) -> dict[str, Any]:
    case = db.get_case(case_id)
    if not case:
        raise HTTPException(status_code=404, detail="Case not found.")
    if case["policy_decision"] != "REFUND_CANDIDATE" or case["status"] != "AWAITING_MERCHANT_APPROVAL":
        raise HTTPException(status_code=409, detail=f"This case is not refund-eligible. Current decision: {case['policy_decision']}.")
    if case.get("refund_status") in {"COMPLETED", "PENDING"}:
        raise HTTPException(status_code=409, detail="A refund was already submitted for this case; check the saved PayPal status.")

    order = db.get_order(case["order_id"])
    capture_id = order.get("paypal_capture_id") if order else None
    if not capture_id:
        raise HTTPException(status_code=409, detail="Link a verified completed PayPal Sandbox capture first via POST /orders/{order_id}/link-capture.")

    try:
        capture = get_capture(capture_id)
    except PayPalError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    if capture.get("status") != "COMPLETED":
        raise HTTPException(status_code=409, detail=f"PayPal capture is not refundable in its current state: {capture.get('status')}.")
    amount = capture.get("amount") or {}
    if str(amount.get("value")) != str(order["amount"]) or amount.get("currency_code") != order["currency"]:
        raise HTTPException(status_code=409, detail="PayPal capture amount/currency does not match the order; refund blocked.")

    # Persist the same idempotency key before calling PayPal so retries can reuse it after a timeout.
    request_id = case.get("paypal_request_id") or f"resolveos-{case_id.lower()}"
    db.update_case(case_id, status="REFUND_SUBMITTING", paypal_request_id=request_id)
    db.log_audit(case_id, actor, "MERCHANT_APPROVED_REFUND", {"capture_id": capture_id, "request_id": request_id, "amount": amount})
    try:
        refund = refund_capture(capture_id, request_id)
    except PayPalError as exc:
        db.update_case(case_id, status="REFUND_REQUIRES_RECONCILIATION")
        db.log_audit(case_id, actor, "REFUND_API_ERROR", {"error": str(exc), "request_id": request_id})
        raise HTTPException(status_code=502, detail=f"PayPal refund request did not return success. Check Sandbox activity before retrying. Request ID: {request_id}. Details: {exc}") from exc

    refund_id = refund.get("id")
    refund_status = refund.get("status", "UNKNOWN")
    new_status = "REFUND_COMPLETED" if refund_status == "COMPLETED" else "REFUND_PENDING"
    db.update_case(case_id, status=new_status, paypal_refund_id=refund_id, refund_status=refund_status)
    if refund_status == "COMPLETED":
        # Local display state only; PayPal remains the payment source of truth.
        with db.connect() as conn:
            conn.execute("UPDATE orders SET refund_status = 'REFUNDED' WHERE order_id = ?", (order["order_id"],))
    db.log_audit(case_id, actor, "PAYPAL_REFUND_RESPONSE", {"refund_id": refund_id, "refund_status": refund_status, "response": refund})
    return {"case_id": case_id, "status": new_status, "refund_id": refund_id, "refund_status": refund_status, "paypal_response": refund}
